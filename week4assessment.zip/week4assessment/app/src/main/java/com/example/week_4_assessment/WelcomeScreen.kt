package com.example.week_4_assessment

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class WelcomeScreen : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_welcome_screen)
    }
}